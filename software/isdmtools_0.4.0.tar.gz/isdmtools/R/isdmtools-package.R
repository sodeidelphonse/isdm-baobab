#' @title A Reproducible R Framework for Spatial Data Resampling and Multisource Validation of Integrated Species Distribution Models
#'
#' @description
#' `isdmtools` provides a set of tools for preparing, analysing and visualising spatial data for integrated species distribution models (ISDMs).
#' It been developed to assist users in preparing multisource point-level spatial datasets for block cross-validation, analysing the
#' habitat suitability from the joint model predictions, with a focus on Bayesian inference and visualising the results.
#'
#' The package also provides a holistic view of model performance by computing a comprehensive evaluation metrics, including
#' ROC-based and error-based weighted composite scores and performing posterior predictive checks.
#'
#' @seealso
#' Useful links:
#' \itemize{
#'   \item Report bugs at \url{https://github.com/sodeidelphonse/isdmtools/issues}
#'   \item Official documentation: \url{https://sodeidelphonse.github.io/isdmtools/}
#' }
#'
#' For a complete guide on the workflow, see the package vignettes:
#' \itemize{
#'   \item \code{vignette("isdmtools", package = "isdmtools")}: Get started with the basics.
#'   \item \code{vignette("isdm-workflow", package = "isdmtools")}: Detailed evaluation workflow.
#' }
#'
#' @name isdmtools-package
#' @aliases isdmtools
#'
#' @importFrom rlang .data
#' @keywords internal
"_PACKAGE"
