#--------------------------------------------------------------------------------------------------------
#--- Function to compute comprehensive evaluation metrics for integrated or standalone spatial models
#--------------------------------------------------------------------------------------------------------

#' @title Compute Evaluation Metrics for Integrated Spatial Models from Multisource Datasets
#'
#' @description This function computes a wide range of evaluation metrics for a single-layer raster of model predictions against a list of one or more point-based datasets.
#' It is designed to handle different data types (presence-only, presence-absence, and count data) and provides individual metrics as well as dataset-weighted composite scores.
#'
#' @param test_data A named `list` of `sf` objects. Each `sf` object represents a different test dataset and must contain point geometries. The function will loop through each named dataset in the list.
#' In particular, `test_data` can be a 'fold' from the \link{create_folds} and \link{extract_fold} outputs, if independent validation datasets are not available.
#' @param prob_raster A `SpatRaster` object with unique layer containing the model's predictions on a probability scale (0-1).
#' It represents a suitability index, and its values are used to compute all ROC-based metrics (e.g., AUC, TSS, F1 score). This argument is optional if only continuous-outcome metrics are requested for count data.
#' @param expected_response A `SpatRaster` object containing the model's predictions on a continuous scale (i.e. counts or rate if offset is used; see \link{suitability_index}).
#' Its values are used to compute all continuous-outcome metrics (e.g., RMSE, MAE, MAPE). This argument is required if a continuous-outcome metric is requested.
#' @param xy_excluded An optional `SpatVector` or `sf` object representing locations where pseudo-absence points should not be sampled, such as occupied areas or known background points.
#' Only relevant for presence-only (PO) data. Default is `NULL`.
#' @param n_background integer. It specifies the number of pseudo-absence points to sample for presence-only data. Default is 1000 (see \link{sample_background}).
#' @param response_counts character. The column name in the `sf` objects that contains observed counts. Default is 'counts' and must be standardized across all count data sets.
#' Exceptionally, positive measurements (e.g. biomass) are supported by allowing exposure to its default value. In such cases, only continuous-outcome metrics can be requested.
#' @param response_pa character. The column name in the `sf` objects that contains presence-absence data (1 for presence, 0 for absence). Default is 'present' and must be standardized across all PA data sets.
#' @param seed integer. It sets the seed for random number generation, used for pseudo-absence sampling to ensure reproducibility. Default is 25.
#' @param threshold_method character. The method to be used for selecting the threshold for converting probabilities to binary outcomes. Options are 'best' (using `best_method`) or 'fixed'. Default is "best".
#' @param best_method character. The method to be used for selecting the best threshold when `threshold_method` is 'best'. Options are 'youden' or 'closest.topleft'.
#' Default is "youden" criterion which maximizes the sensitivity and specificity.
#' @param fixed_threshold numeric. The value (0-1) to be used as the fixed threshold when `threshold_method` is 'fixed'. Default is `NA_real_`.
#' @param best_threshold_policy character. Specifies the policy for selecting a threshold when multiple thresholds yield the same 'best' value.
#' Options are "first", "last", "max.prec" (max precision), "max.recall" (max recall), "max.accu" (max accuracy), or "max.f1" (max F1 score). Default is "first".
#' @param metrics character. A vector of the metric names to compute.
#' If `NULL`, "auc" (area under the ROC curve), "tss" (true skill statistics), "f1" (F1 score), "accuracy", "precision", and "recall" are computed for ROC-based metrics
#' while "rmse" (root mean squared error), "mae" (mean absolute error) and "r2" (pseudo R-squared) are computed for error-based metrics.
#' @param overall_roc_metrics character. A vector of a subset of ROC-based metrics to be used for the overall composite score (`TOT_ROC_SCORE`).
#' Allowed options are "auc", "tss", "accuracy", and "f1". If `NULL`, the sensible default is "auc", "tss" and "accuracy".
#' This metric is useful when the objective is to obtain a rapid overview of the rank of multiple candidate models fitted to datasets via blocked cross-validation using multi-criteria assessment.
#' @param overall_error_metrics character. A vector of a subset of continuous outcome metrics to be used for the overall composite score (`TOT_ERROR_SCORE`). Allowed options are "rmse", "mae", and "r2".
#' If `NULL`, the default is "rmse" and "mae". In order to obtain an overall interpretable score, it is imperative to select metrics that have the same scale.
#' @param is_pred_rate logical. If `TRUE`, it indicates that the `expected_response` contains predictions at the intensity (per-unit-of-exposure) scale (typical for Bayesian models with offset from `inlabru`).
#' If `FALSE`, it assumes predictions are at the original scale (e.g., counts). Default is `FALSE`.
#' @param exposure character. The column name in the `sf` objects that contains the exposure variable (offset). Only relevant for count (and sometimes presence-absence) data and must be standardized across all these types of datasets.
#' If `is_pred_rate` is `TRUE`, observed counts are rescaled by this exposure variable. Default is `NULL`.
#' @param ... Additional arguments to be passed on to internal functions, particularly \link[pROC]{coords} function.
#'
#' @details The function handles three main data types and any combination thereof:
#'
#' \itemize{
#'   \item \strong{Presence-Absence (PA) Data:} The function uses the `response_pa` column and `prob_raster` to calculate all ROC-based metrics (see \link[pROC]{coords}, for more details on available metrics).
#'   \item \strong{Count Data (or optionally measurements):} The function uses `expected_response` to calculate continuous-outcome metrics and can optionally use `prob_raster` to calculate ROC-based metrics for count data.
#'   \item \strong{Presence-Only (PO) Data:} The function uses the presence points from the `sf` object (`xy_excluded`) and samples `n` pseudo-absence points from the study background (excluding `xy_excluded`) to create a presence-absence dataset for ROC-based metric calculations.
#' }
#'
#' For models based on count data, if a user wants to compute both continuous-outcome and ROC-based metrics, `expected_response` raster must be supplied for the continuous metrics and `prob_raster` must also be supplied for the ROC-based metrics.
#' The `prob_raster` can be obtained by converting the continuous-outcome prediction (e.g., `linear predictor`) to a suitability index using the \link{suitability_index} function.
#'
#' The available continuous-outcome metrics are given as follows:
#' \itemize{
#' \item **Root Mean Squared Error (RMSE)**: A measure of the average magnitude of the errors. It's the square root of the average of squared differences between prediction and actual observation. It gives higher weight to large errors.
#'    \deqn{RMSE = \sqrt{\frac{1}{n}\sum_{i=1}^{n}(\hat{y_i} - y_i)^2}}.
#' \item **Mean Absolute Error (MAE)**: A measure of the average magnitude of the errors without considering their direction. It is the average of the absolute differences between prediction and actual observation.
#'    \deqn{MAE = \frac{1}{n}\sum_{i=1}^{n}|\hat{y_i} - y_i|}.
#' \item **Mean Absolute Percentage Error (MAPE)**: A measure of prediction accuracy as a percentage. It is calculated as the average of the absolute percentage errors for each observation. It can be useful for comparing performance across different datasets or models.
#'    \deqn{MAPE = \frac{100\%}{n}\sum_{i=1}^{n}|\frac{\hat{y_i} - y_i}{y_i}|}.
#' \item **Pseudo R-squared (\eqn{R^2})**: A measure of the proportion of variance in the observed data explained by the model's predictions.
#'    \deqn{R^2 = 1 - \frac{SS_{res}}{SS_{tot}}}
#'    Where:
#'   \itemize{
#'   \item \eqn{y_i} is the observed continuous value at location \eqn{i}.
#'   \item \eqn{\hat{y}_i} is the predicted value from the model at location \eqn{i} (e.g., the posterior mean of the predictions).
#'   \item \eqn{\bar{y}} is the mean of all observed values.
#'   \item \eqn{SS_{res}} is the residual sum of squares, which measures the discrepancy between the observed and predicted values:
#'     \deqn{SS_{res} = \sum_{i=1}^{n}(y_i - \hat{y}_i)^2}
#'   \item \eqn{SS_{tot}} is the total sum of squares, which measures the total variance in the observed data:
#'     \deqn{SS_{tot} = \sum_{i=1}^{n}(y_i - \bar{y})^2}
#'   }
#' }
#'
#' A `weighted composite score` (`<METRIC>_Comp`) is computed for each requested metric by taking the sample-size-weighted average across all datasets where the metric was successfully calculated.
#' A `total composite score` (`TOT_ROC_SCORE` or `TOT_ERROR_SCORE`) is also computed by averaging the selected metrics in the corresponding 'overall metrics' character vector.
#' It can be viewed as a quick *multi-criterion decision metric* for multiple models comparison.
#'
#' @return An object of class `ISDMmetrics`. It is named `list` containing all requested metrics. The names follow a consistent convention:
#' \itemize{
#'   \item `"<METRIC>_<DATASET_NAME>"`: Individual metric score for each dataset.
#'   \item `"<METRIC>_Comp"`: The sample-size-weighted composite score for a given metric across all valid datasets.
#'   \item `"TOT_ROC_SCORE"`: The overall ROC-based composite score, averaged across the selected `overall_roc_metrics`.
#'   \item `"TOT_ERROR_SCORE"`: The overall error-based composite score, averaged across `overall_error_metrics`.
#' }
#'
#' The \code{ISDMmetrics} object is a list containing performance values for individual datasets and composite scores.
#' Use \code{as.data.frame()} to flatten these for cross-validation summaries.
#'
#' @examples
#' \dontrun{
#' # Assuming you have dummy prediction rasters and a list of sf objects
#' # with 'counts' and 'present' columns for counts and PA data, respectively.
#'
#' # Example 1: Compute metrics for a presence-absence model
#' # pa_metrics <- compute_metrics(
#' #   test_data = list(ds1 = my_pa_sf),
#' #   prob_raster = prob_raster,  # compulsory prob_raster
#' #   response_pa = "present"     # default labels column for all PA data
#' # )
#'
#' # Example 2: Compute continuous-outcome metrics for a count-based model
#' # cont_metrics <- compute_metrics(
#' #   test_data = list(ds1 = my_count_sf),
#' #   expected_response = expected_raster, # prediction on count scale
#' #   response_count = "counts",           # default labels column for all counts
#' #   metrics = c("rmse", "mae", "mape")
#' # )
#'
#' # Example 3: Compute both continuous and ROC-based metrics for a count model
#' # The user must first generate a suitability index (prob_raster & expected_response)
#' # from the linear scale prediction (pred_eta).
#'
#' # expected_raster <- suitability_index(pred_eta,
#' #                    response_type = "count",
#' #                    output_format = "response")
#' # suitability_raster <- suitability_index(pred_eta,
#' #                       response_type = "count",
#' #                       output_format = "prob")
#' # full_metrics <- compute_metrics(
#' #   test_data = list(ds1 = my_count_sf),
#' #   prob_raster = suitability_raster,
#' #   expected_response = expected_raster,
#' #   metrics = c("rmse", "mae", "auc", "tss")
#' # )
#'
#' # Example 4: Handle an inlabru-like model with an offset term
#' # The `expected_response` raster is at the intensity scale (rate).
#'
#' # cont_metrics <- compute_metrics(
#' #   test_data = list(ds1 = my_count_sf),
#' #   prob_raster = suitability_raster,
#' #   expected_response = expected_raster,
#' #   metrics = c("rmse", "auc", "tss"),
#' #   is_pred_rate = TRUE,
#' #   exposure = "exposure_col" # Exposure column (e.g. sampling unit area)
#' # )
#'
#' # Example 5: Compute dataset-specific and weighted composite metrics for a joint model
#' # expected_raster  <- suitability_index(pred_eta,
#' #                     response_type = "count.pa",
#' #                     output_format = "response")
#' # suitability_raster <- suitability_index(pred_eta,
#' #                       response_type = "count.pa",
#' #                       has_offset = FALSE)
#' # full_metrics <- compute_metrics(
#' #   test_data = list(ds1 = my_count_sf, ds2 = my_pa_sf),
#' #   prob_raster = suitability_raster,
#' #   expected_response = expected_raster,
#' #   metrics = c("rmse", "mae", "auc", "tss", "accuracy")
#' # )
#' }
#' @export
#' @family ISDM evaluation methods
#' @seealso \code{\link{extract_fold}}, \code{\link{sample_background}}
#'
compute_metrics <- function(test_data,
                            prob_raster = NULL,
                            xy_excluded = NULL,
                            expected_response = NULL,
                            n_background = 1000,
                            response_counts = "counts",
                            response_pa = "present",
                            threshold_method = c("best", "fixed"),
                            best_method = c("youden", "closest.topleft"),
                            fixed_threshold = NA_real_,
                            best_threshold_policy = c("first", "last", "max.prec", "max.recall", "max.accu", "max.f1"),
                            metrics = NULL,
                            overall_roc_metrics = NULL,
                            overall_error_metrics = NULL,
                            is_pred_rate = FALSE,
                            exposure = NULL,
                            seed = 25, ...) {
  # Master list of allowed metrics
  error_metrics <- c("rmse", "mae", "mape", "r2")
  roc_metrics <- c(
    "auc", "tss", "accuracy", "precision", "recall", "specificity",
    "npv", "fpr", "fnr", "fdr", "f1", "threshold", "tpr", "tnr"
  )
  master_allowed_metrics <- c(roc_metrics, error_metrics)

  # --- Critical validation for required inputs ----
  threshold_method <- match.arg(threshold_method)
  best_method <- match.arg(best_method)
  best_threshold_policy <- match.arg(best_threshold_policy)

  has_roc_metrics <- any(roc_metrics %in% metrics)

  if (has_roc_metrics && is.null(prob_raster)) {
    stop("ROC-based metrics were requested but 'prob_raster' (suitability index) was not provided.", call. = FALSE)
  }

  has_error_metrics <- any(error_metrics %in% metrics)

  if (has_error_metrics && is.null(expected_response)) {
    stop("Continuous-outcome metrics were requested but 'expected_response' raster was not provided.", call. = FALSE)
  }

  default_roc_metrics <- c("auc", "tss", "accuracy", "f1", "recall", "precision")
  default_error_metrics <- c("rmse", "mae", "r2")

  if (is.null(metrics)) {
    if (!is.null(prob_raster) && !is.null(expected_response)) {
      metrics <- c(default_roc_metrics, default_error_metrics)
    } else if (!is.null(prob_raster)) {
      metrics <- default_roc_metrics
    } else if (!is.null(expected_response)) {
      metrics <- default_error_metrics
    }
  }

  # --- Validation of the main data ----
  if (!is.logical(is_pred_rate) || length(is_pred_rate) != 1) {
    stop("'is_pred_rate' must be a single logical value (TRUE or FALSE).", call. = FALSE)
  }

  if (threshold_method == "fixed") {
    if (!is.numeric(fixed_threshold) || length(fixed_threshold) != 1 || !is.finite(fixed_threshold) || fixed_threshold < 0 || fixed_threshold > 1) {
      stop("'fixed_threshold' must be a single finite numeric value between 0 and 1 when 'threshold_method' is 'fixed'.", call. = FALSE)
    }
  }

  if (!is.null(prob_raster) || !missing(prob_raster)) {
    if (!inherits(prob_raster, "SpatRaster")) {
      stop(sprintf("'%s' must be a SpatRaster object.", prob_raster), call. = FALSE)
    } else {
      vals <- terra::values(prob_raster)[, 1]
      vals <- vals[!is.na(vals)]
      if (length(vals) == 0) {
        stop("Probabilities raster contains only NA values. Cannot compute metrics.", call. = FALSE)
      }

      if (any(vals < 0) || any(vals > 1)) {
        stop("Probabilities raster must be positive with range [0, 1]", call. = FALSE)
      }

      if (terra::nlyr(prob_raster) != 1) {
        stop(sprintf("The input '%s' must be a single-layer raster.", prob_raster), call. = FALSE)
      }
    }
  }

  if (!is.null(expected_response)) {
    if (!inherits(expected_response, "SpatRaster")) {
      stop(sprintf("'%s' must be a SpatRaster object.", deparse(substitute(expected_response))), call. = FALSE)
    }
    vals <- terra::values(expected_response)[, 1]
    vals <- vals[!is.na(vals)]
    if (any(vals < 0)) {
      stop("'expected_response' must be positive values.", call. = FALSE)
    }
  }

  if (!inherits(test_data, "list") || is.null(names(test_data))) {
    stop(sprintf("'%s' must be a named list.", deparse(substitute(test_data))), call. = FALSE)
  }

  for (ds_name in names(test_data)) {
    if (!inherits(test_data[[ds_name]], "sf")) {
      stop(sprintf("All elements in 'test_data' must be 'sf' objects. '%s' is not.", ds_name), call. = FALSE)
    }
    if (!inherits(sf::st_geometry(test_data[[ds_name]]), "sfc_POINT")) {
      warning(sprintf("Dataset '%s' in 'test_data' does not contain point geometries and could cause issue to values extraction.", ds_name), call. = FALSE)
    }
  }

  # --- Validation of arguments for the overall composite scores ----
  if (!all(metrics %in% master_allowed_metrics)) {
    stop(sprintf("Invalid metric(s) requested. Allowed metrics are: %s", paste(master_allowed_metrics, collapse = ", ")), call. = FALSE)
  }

  if (is.null(overall_roc_metrics)) {
    roc_metrics_to_average <- c("auc", "tss", "accuracy")
    message(sprintf(
      "No 'overall_roc_metrics' specified. Overall ROC score will be computed for available metrics among: %s.",
      paste(toupper(roc_metrics_to_average), collapse = ", ")
    ))
  } else {
    if (!is.character(overall_roc_metrics)) {
      stop("'overall_roc_metrics' must be a character vector of metric names.", call. = FALSE)
    }
    valid_options <- c("auc", "tss", "accuracy", "f1")
    if (!all(overall_roc_metrics %in% valid_options)) {
      stop(sprintf(
        "Invalid metric(s) selected for 'overall_roc_metrics': %s. Allowed composite metrics are: %s.",
        paste(setdiff(overall_roc_metrics, valid_options), collapse = ", "),
        paste(valid_options, collapse = ", ")
      ), call. = FALSE)
    }
    if (!all(overall_roc_metrics %in% metrics)) {
      stop(sprintf(
        "Metric(s) selected for 'overall_roc_metrics' (%s) were not requested in the general 'metrics' argument. Please ensure all composite metrics are also in 'metrics'.",
        paste(setdiff(overall_roc_metrics, metrics), collapse = ", ")
      ), call. = FALSE)
    }
    if (length(overall_roc_metrics) < 1) {
      stop("At least one metric must be requested for 'overall_roc_metrics' to calculate an overall composite score.", call. = FALSE)
    }
    roc_metrics_to_average <- overall_roc_metrics
  }

  if (is.null(overall_error_metrics)) {
    error_metrics_to_average <- c("rmse", "mae")
    message(sprintf(
      "No 'overall_error_metrics' specified. Overall continuous-outcome score will be computed for available metrics among: %s.",
      paste(toupper(error_metrics_to_average), collapse = ", ")
    ))
  } else {
    if (!is.character(overall_error_metrics)) {
      stop("'overall_error_metrics' must be a character vector of metric names.", call. = FALSE)
    }
    valid_options <- c("rmse", "mae", "r2")
    if (!all(overall_error_metrics %in% valid_options)) {
      stop(sprintf(
        "Invalid metric(s) selected for 'overall_error_metrics': %s. Allowed composite metrics are: %s.",
        paste(setdiff(overall_error_metrics, valid_options), collapse = ", "),
        paste(valid_options, collapse = ", ")
      ), call. = FALSE)
    }
    if (!all(overall_error_metrics %in% metrics)) {
      stop(sprintf(
        "Metric(s) selected for 'overall_error_metrics' (%s) were not requested in the general 'metrics' argument. Please ensure all composite metrics are also in 'metrics'.",
        paste(setdiff(overall_error_metrics, metrics), collapse = ", ")
      ), call. = FALSE)
    }
    if (length(overall_error_metrics) < 1) {
      stop("At least one metric must be requested for 'overall_error_metrics' to calculate an overall composite score.", call. = FALSE)
    }
    error_metrics_to_average <- overall_error_metrics
  }

  # set seed for background sampling
  set.seed(seed)
  all_metrics <- list()
  final_bg_obj <- NULL # Ensures the attribute assignment at the end always works

  # --- Loop through each dataset in test_data -----
  for (ds_name in names(test_data)) {
    current_data <- test_data[[ds_name]]
    current_sample_size <- nrow(current_data)
    loc <- sf::st_coordinates(current_data)[, c("X", "Y")]

    metrics_ds <- list(sample_size = current_sample_size)
    for (m in metrics) {
      metrics_ds[[m]] <- NA_real_
    }

    if (current_sample_size == 0) {
      message(sprintf("Skipping metrics for empty dataset: '%s'", ds_name))
      all_metrics[[ds_name]] <- metrics_ds
      next
    }

    is_count_data <- response_counts %in% names(current_data)
    is_pa_data <- response_pa %in% names(current_data)

    # --- Conditional continuous-outcome metrics calculation ---
    if (has_error_metrics && response_counts %in% names(current_data)) {
      raw_expected <- terra::extract(expected_response, loc)[, 1]
      valid_idx <- is.finite(raw_expected)

      if (any(valid_idx)) {
        if (isTRUE(is_pred_rate)) {
          if (is.null(exposure)) {
            warning("Predictions are marked as 'intensity', but no 'exposure' was provided. Assuming exposure is 1.", call. = FALSE)
            predicted <- raw_expected[valid_idx]
            observed <- current_data[[response_counts]][valid_idx]
          } else {
            predicted <- raw_expected[valid_idx]
            observed <- current_data[[response_counts]][valid_idx] / current_data[[exposure]][valid_idx]
          }
        } else {
          if (!is.null(exposure)) {
            warning("Predictions are not marked as 'intensity(rate)', but an 'exposure' was supplied. Assuming predictions are already on the count scale.", call. = FALSE)
          }
          predicted <- raw_expected[valid_idx]
          observed <- current_data[[response_counts]][valid_idx]
        }

        if ("rmse" %in% metrics) metrics_ds$rmse <- rmse(observed, predicted)
        if ("mae" %in% metrics) metrics_ds$mae <- mae(observed, predicted)
        if ("mape" %in% metrics) metrics_ds$mape <- mape(observed, predicted)
        if ("r2" %in% metrics) metrics_ds$r2 <- r_squared(observed, predicted)
      } else {
        message(sprintf("Skipping continuous-outcome metrics for '%s' due to no valid predictions after filtering.", ds_name))
      }
    }

    # --- ROC-based metrics (AUC, TSS, Precision, Recall, Accuracy, etc.) ---
    if (has_roc_metrics) {
      raw_prob <- terra::extract(prob_raster, loc)[, 1]
      valid_idx <- is.finite(raw_prob)
      prob_roc <- raw_prob[valid_idx]

      eval_resp_roc <- NULL
      if (is_count_data) {
        eval_resp_roc <- ifelse(current_data[[response_counts]] > 0, 1, 0)[valid_idx]
        metrics_ds$sample_size <- length(prob_roc)
      } else if (is_pa_data) {
        eval_resp_roc <- current_data[[response_pa]][valid_idx]
        metrics_ds$sample_size <- length(prob_roc)
      } else {
        bg_points_po <- sample_background(
          mask = prob_raster, points = xy_excluded,
          n = n_background, xy = TRUE, values = FALSE
        )
        final_bg_obj <- bg_points_po

        if (!is.null(bg_points_po$bg)) {
          prob_bg_po <- terra::extract(prob_raster, bg_points_po$bg)[, 1]
          prob_bg_po <- prob_bg_po[is.finite(prob_bg_po)]

          if (length(prob_roc) > 0 && length(prob_bg_po) > 0) {
            eval_resp_roc <- c(rep(1, length(prob_roc)), rep(0, length(prob_bg_po)))
            prob_roc_po <- c(prob_roc, prob_bg_po)
            metrics_ds$sample_size <- length(prob_roc)
          } else {
            message(sprintf(
              "Not enough valid presence (%s) or background (%s) points to compute ROC for '%s' (PO data).",
              length(prob_roc), length(prob_bg_po), ds_name
            ))
          }
        } else {
          message(sprintf("No background points sampled for '%s' (PO data). Cannot compute ROC metrics.", ds_name))
        }
      }

      # --- Check if we have valid data to compute ROC metrics ----
      if (!is.null(prob_roc) && length(unique(eval_resp_roc)) == 2 && length(prob_roc) > 0) {
        if (is_count_data || is_pa_data) {
          roc_obj <- pROC::roc(eval_resp_roc, prob_roc, quiet = TRUE)
        } else {
          roc_obj <- pROC::roc(eval_resp_roc, prob_roc_po, quiet = TRUE)
        }

        if ("auc" %in% metrics) {
          metrics_ds$auc <- as.numeric(roc_obj$auc)
        }
        if ("tss" %in% metrics) {
          metrics_ds$tss <- max(roc_obj$sensitivities + roc_obj$specificities - 1)
        }

        # List all metrics that coords() can return directly.
        metric_map_for_coords <- c(
          "threshold" = "threshold",
          "specificity" = "specificity",
          "recall" = "sensitivity", # sensitivity is recall
          "tpr" = "sensitivity", # sensisitivity is tpr
          "tnr" = "specificity", # sepecificity is tnr
          "precision" = "ppv", # ppv is precision
          "accuracy" = "accuracy",
          "npv" = "npv",
          "fpr" = "fpr",
          "fnr" = "fnr",
          "fdr" = "fdr"
        )
        coords_rets_to_pass <- unique(unname(metric_map_for_coords[names(metric_map_for_coords) %in% metrics]))
        coords_rets_to_pass <- coords_rets_to_pass[!is.na(coords_rets_to_pass) & !is.null(coords_rets_to_pass)]

        if (length(coords_rets_to_pass) > 0) {
          coords_x_val <- if (threshold_method == "best") "best" else fixed_threshold
          coords_results_df <- pROC::coords(
            roc = roc_obj,
            x = coords_x_val,
            ret = coords_rets_to_pass,
            best.method = best_method,
            transpose = FALSE, ...
          )

          temp_metrics_values <- list()
          for (coord_metric_name in names(metric_map_for_coords)) {
            pROC_col_name <- metric_map_for_coords[coord_metric_name]
            if (pROC_col_name %in% names(coords_results_df)) {
              temp_metrics_values[[coord_metric_name]] <- coords_results_df[[pROC_col_name]]
            } else {
              temp_metrics_values[[coord_metric_name]] <- rep(NA_real_, nrow(coords_results_df))
            }
          }

          if ("f1" %in% metrics) {
            temp_metrics_values$f1 <- 2 * (temp_metrics_values$precision * temp_metrics_values$recall) /
              (temp_metrics_values$precision + temp_metrics_values$recall)
            temp_metrics_values$f1[is.nan(temp_metrics_values$f1) | is.infinite(temp_metrics_values$f1)] <- -Inf
          }

          # Find row index for the chosen optimal threshold
          selected_idx <- 1
          if (threshold_method == "best" && nrow(coords_results_df) > 1) {
            if (best_threshold_policy == "first") {
              selected_idx <- 1
            } else if (best_threshold_policy == "last") {
              selected_idx <- nrow(coords_results_df)
            } else if (best_threshold_policy == "max.prec" && "precision" %in% names(temp_metrics_values)) {
              selected_idx <- which.max(temp_metrics_values$precision)
            } else if (best_threshold_policy == "max.recall" && "recall" %in% names(temp_metrics_values)) {
              selected_idx <- which.max(temp_metrics_values$recall)
            } else if (best_threshold_policy == "max.accu" && "accuracy" %in% names(temp_metrics_values)) {
              selected_idx <- which.max(temp_metrics_values$accuracy)
            } else if (best_threshold_policy == "max.f1" && "f1" %in% names(temp_metrics_values)) {
              selected_idx <- which.max(temp_metrics_values$f1)
            } else {
              message(sprintf("Policy '%s' cannot be applied for '%s' due to missing required metrics. Falling back to 'first' threshold.", best_threshold_policy, ds_name))
              selected_idx <- 1
            }
            if (length(selected_idx) > 1) {
              selected_idx <- selected_idx[1]
              message(sprintf("Multiple thresholds tied for '%s' with policy '%s'. Selecting the first one encountered.", ds_name, best_threshold_policy))
            }
          }

          for (metric_name_to_assign in names(temp_metrics_values)) {
            if (metric_name_to_assign %in% metrics) {
              metrics_ds[[metric_name_to_assign]] <- temp_metrics_values[[metric_name_to_assign]][selected_idx]
            }
          }
        }
      } else {
        message(sprintf("Skipping ROC-based metrics for '%s' due to single response class or no valid predictions.", ds_name))
      }
    }

    all_metrics[[ds_name]] <- metrics_ds
  }

  # --- Compute Weighted Composite Scores for requested metrics ----
  weighted_composite_scores <- list()

  for (metric_name in metrics) {
    if (metric_name == "threshold") {
      next
    }

    current_metric_values <- rep(NA_real_, length(test_data))
    current_sample_sizes <- rep(NA_real_, length(test_data))
    names(current_metric_values) <- names(test_data)
    names(current_sample_sizes) <- names(test_data)

    for (i in seq_along(test_data)) {
      ds_name <- names(test_data)[i]
      if (!is.null(all_metrics[[ds_name]]) && metric_name %in% names(all_metrics[[ds_name]])) {
        current_metric_values[ds_name] <- all_metrics[[ds_name]][[metric_name]]
        current_sample_sizes[ds_name] <- all_metrics[[ds_name]]$sample_size
      }
    }

    if (metric_name %in% error_metrics) {
      is_count_ds <- unlist(lapply(test_data, function(x) response_counts %in% names(x)))
      names(is_count_ds) <- names(test_data)
      valid_indices <- !is.na(current_metric_values) &
        !is.na(current_sample_sizes) & current_sample_sizes > 0 & is_count_ds
    } else {
      valid_indices <- !is.na(current_metric_values) &
        !is.na(current_sample_sizes) & current_sample_sizes > 0
    }

    weighted_score <- NA_real_
    if (any(valid_indices)) {
      valid_metric_values <- current_metric_values[valid_indices]
      valid_weights <- current_sample_sizes[valid_indices]
      if (sum(valid_weights, na.rm = TRUE) > 0) {
        weighted_score <- sum(valid_metric_values * valid_weights) / sum(valid_weights, na.rm = TRUE)
      }
    }
    weighted_composite_scores[[paste0(toupper(metric_name), "_Comp")]] <- weighted_score
  }

  # Overall ROC-based Composite Score
  TOT_ROC_SCORE <- NA_real_
  relevant_roc_scores_names <- paste0(toupper(roc_metrics_to_average), "_Comp")
  available_relevant_roc_scores <- weighted_composite_scores[relevant_roc_scores_names]
  available_relevant_roc_scores <- unlist(available_relevant_roc_scores[!sapply(available_relevant_roc_scores, is.null)])
  available_relevant_roc_scores <- available_relevant_roc_scores[!is.na(available_relevant_roc_scores)]

  if (length(available_relevant_roc_scores) > 0) {
    TOT_ROC_SCORE <- mean(available_relevant_roc_scores, na.rm = TRUE)
  } else {
    message("Cannot compute an overall ROC composite score as no relevant composite metrics were available or calculated.")
  }

  # Overall Continuous-outcome Composite Score
  TOT_ERROR_SCORE <- NA_real_
  relevant_cont_scores_names <- paste0(toupper(error_metrics_to_average), "_Comp")
  available_relevant_cont_scores <- weighted_composite_scores[relevant_cont_scores_names]
  available_relevant_cont_scores <- unlist(available_relevant_cont_scores[!sapply(available_relevant_cont_scores, is.null)])
  available_relevant_cont_scores <- available_relevant_cont_scores[!is.na(available_relevant_cont_scores)]

  if (length(available_relevant_cont_scores) > 0) {
    TOT_ERROR_SCORE <- mean(available_relevant_cont_scores, na.rm = TRUE)
  } else {
    message("Cannot compute an overall continuous-outcome composite score as no relevant composite metrics were available or calculated.")
  }

  return_list <- list()
  for (ds_name in names(test_data)) {
    for (metric_name in metrics) {
      if (!is.null(all_metrics[[ds_name]]) && metric_name %in% names(all_metrics[[ds_name]])) {
        return_list[[paste0(toupper(metric_name), "_", ds_name)]] <- all_metrics[[ds_name]][[metric_name]]
      }
    }
  }

  return_list <- c(return_list, weighted_composite_scores)
  return_list$TOT_ROC_SCORE <- TOT_ROC_SCORE
  return_list$TOT_ERROR_SCORE <- TOT_ERROR_SCORE

  # Capture settings for replication/summary and assign class
  settings <- list(
    n_background = n_background,
    seed = seed,
    threshold_method = threshold_method,
    best_method = best_method,
    fixed_threshold = fixed_threshold,
    is_pred_rate = is_pred_rate,
    timestamp = Sys.time()
  )

  class(return_list) <- c("ISDMmetrics", "list")
  attr(return_list, "settings") <- settings
  attr(return_list, "bg_points") <- final_bg_obj

  return(return_list)
}


#--- Methods associated to ISDMmetrics ------------------------

#' @title Methods for ISDMmetrics Objects
#'
#' @description Objects of class \code{ISDMmetrics} are returned by \code{\link{compute_metrics}}.
#' These methods provide structured ways to view, summarize and manipulate the evaluation results.
#'
#' @param x An object of class \code{ISDMmetrics}.
#' @param object An object of class \code{ISDMmetrics}.
#' @param include_composite Logical. Should the weighted composite scores be included in the plot? Defaults to \code{TRUE}.
#' @param ... Additional arguments passed on to the method.
#'
#' @return
#' \itemize{
#'   \item \code{as.data.frame}: Returns a tidy \code{data.frame} in long format.
#'   \item \code{print}: Invisibly returns the original object.
#'   \item \code{summary}: Invisibly returns \code{NULL}.
#'   \item \code{plot}: Returns a \code{ggplot2} object.
#'   \item \code{[}: Returns a subset of \code{ISDMmetrics} object.
#' }
#'
#' @name ISDMmetrics-methods
#' @rdname ISDMmetrics-methods
#' @family ISDM evaluation methods
#' @export
#'
#' @examples
#' \dontrun{
#' #--- Compute metrics for an Integrated SDM
#' # This object will contain metrics for e.g., Presence-only and Count data
#' eval_results <- compute_metrics(
#'   test_data = test_data,
#'   prob_raster = suitability_raster,
#'   expected_response = expected_raster,
#'   n_background = 1000,
#'   metrics = c("rmse", "mae", "auc", "tss"),
#'   is_pred_rate = TRUE, # model with offset
#'   exposure = "area" # standardized exposure name across the counts data
#' )
#'
#' #--- Quick view of the results
#' print(eval_results)
#'
#' #--- Generate a full replication report
#' # summary.ISDMmetrics shows seeds, threshold logic, and prediction type
#' summary(eval_results)
#'
#' #--- Visual comparison of metrics
#' plot(eval_results, include_composite = TRUE)
#'
#' #--- Background visualization (for Presence-Only data)
#' bg_data <- get_background(eval_results)
#' if (!is.null(bg_data)) {
#'   plot(bg_data)
#' }
#'
#' #--- Export to tabular format for external reports
#' results_df <- as.data.frame(eval_results)
#' head(results_df)
#'
#' #--- Subset specific metrics for custom analysis
#' auc_only <- eval_results[grep("AUC", names(eval_results))]
#' }
#'
as.data.frame.ISDMmetrics <- function(x, ...) {
  all_names <- names(x)
  if (is.null(all_names)) {
    return(data.frame())
  }

  values <- as.numeric(unlist(unclass(x), use.names = FALSE))

  df <- data.frame(
    Full_Name = all_names,
    Value = values,
    stringsAsFactors = FALSE
  )

  parts <- strsplit(df$Full_Name, "_")

  df$Metric <- sapply(parts, `[`, 1)
  df$Source <- sapply(parts, function(p) {
    if (length(p) == 1) {
      return("Global")
    }
    src <- paste(p[-1], collapse = "_")
    if (src == "Comp") {
      return("Weighted Composite")
    }
    return(src)
  })

  df$Source[grepl("^TOT", df$Full_Name)] <- "Global"

  return(df[, c("Full_Name", "Metric", "Source", "Value")])
}

#' @rdname ISDMmetrics-methods
#' @export
print.ISDMmetrics <- function(x, ...) {
  cat("\nISDM Model Evaluation Results\n")
  cat("----------------------------------------------\n")

  df <- as.data.frame(x)

  tot_rows <- df[df$Source == "Global", ]
  ind_rows <- df[!(df$Source %in% c("Global", "Weighted Composite")), ]

  if (nrow(tot_rows) > 0) {
    datasets <- unique(ind_rows$Source)

    cat("Datasets Evaluated:", paste(datasets, collapse = ", "), "\n\n")
    cat("Overall Performance:\n")

    for (i in seq_len(nrow(tot_rows))) {
      label <- gsub("_", " ", tot_rows$Full_Name[i])
      cat(sprintf("  %-18s: %0.4f\n", label, tot_rows$Value[i]))
    }
  } else { # Fallback for subset view
    cat("Note: Subsetted metrics view\n\n")
    for (i in seq_len(nrow(df))) {
      label <- gsub("_", " ", df$Full_Name[i])
      cat(sprintf("  %-18s: %0.4f\n", label, df$Value[i]))
    }
  }

  cat("----------------------------------------------\n")
  invisible(x)
}


#' @rdname ISDMmetrics-methods
#' @export
summary.ISDMmetrics <- function(object, ...) {
  s <- attr(object, "settings")
  bg_attr <- attr(object, "bg_points")

  cat("\n==============================================\n")
  cat("       ISDM EVALUATION SUMMARY REPORT\n")
  cat("==============================================\n")
  if (!is.null(s$timestamp)) cat("Generated on:", format(s$timestamp, "%Y-%m-%d %H:%M:%S"), "\n\n")

  cat("--- Model Evaluation Settings ---\n")
  cat(sprintf("%-20s: %s\n", "Random Seed", ifelse(is.null(s$seed), "N/A", s$seed)))

  bg_display <- if (is.null(bg_attr)) "N/A" else s$n_background

  cat(sprintf("%-20s: %s\n", "Background Points", bg_display))
  if (!is.null(bg_attr)) {
    cat("Spatial Context     : BackgroundPoints object attached\n")
  }

  cat(sprintf("%-20s: %s\n", "Threshold Logic", s$threshold_method))
  if (!is.null(s$threshold_method) && s$threshold_method == "best") {
    cat(sprintf("%-20s: %s\n", "Optimality Criterion", s$best_method))
  }

  is_rate <- if (is.null(s$is_pred_rate)) {
    "Not specified"
  } else if (s$is_pred_rate) {
    "Rate (Count per Offset unit)"
  } else {
    "Absolute Count (No Offset)"
  }
  cat(sprintf("%-20s: %s\n", "Prediction Type", is_rate))

  cat("\n--- Detailed Metric Table ---\n")
  df <- as.data.frame(object)

  # Filter for individual dataset metrics
  ind_df <- df[!(df$Source %in% c("Global", "Weighted Composite")), ]

  if (nrow(ind_df) > 0) {
    metrics_found <- unique(ind_df$Metric)
    datasets_found <- unique(ind_df$Source)

    res_mat <- matrix(NA,
      nrow = length(metrics_found),
      ncol = length(datasets_found),
      dimnames = list(metrics_found, datasets_found)
    )
    for (i in seq_len(nrow(ind_df))) {
      res_mat[ind_df$Metric[i], ind_df$Source[i]] <- ind_df$Value[i]
    }
    print(round(res_mat, 3), na.print = "N/A")
  }

  cat("\n--- Weighted Composite Scores (Weighted) ---\n")
  comp_df <- df[df$Source == "Weighted Composite", ]

  if (nrow(comp_df) > 0) {
    comp_vals <- comp_df$Value
    names(comp_vals) <- comp_df$Metric
    print(round(comp_vals, 3))
  } else {
    cat("No composite scores calculated.\n")
  }

  glob_df <- df[df$Source == "Global", ]

  if (nrow(glob_df) > 0) {
    cat("\n--- Overall Performance ---\n")
    for (i in seq_len(nrow(glob_df))) {
      label <- gsub("_", " ", glob_df$Full_Name[i])
      cat(sprintf("  %-18s: %0.3f\n", label, glob_df$Value[i]))
    }
  }

  cat("==============================================\n")
  invisible(NULL)
}


#' @rdname ISDMmetrics-methods
#' @export
plot.ISDMmetrics <- function(x, include_composite = TRUE, ...) {
  plot_data <- as.data.frame(x)

  # Data-specific metrics and/or composite
  if (include_composite) {
    plot_data <- plot_data[plot_data$Source != "Global", ]
  } else {
    plot_data <- plot_data[!(plot_data$Source %in% c("Global", "Weighted Composite")), ]
  }

  plot_data$Source[plot_data$Source == "Weighted Composite"] <- "Composite"
  if (nrow(plot_data) == 0) stop("No metrics found to plot.")

  # Dynamic color assignment
  unique_sources <- unique(plot_data$Source)
  n_sources <- length(unique_sources)

  cols <- grDevices::hcl.colors(n_sources, palette = "Viridis")
  names(cols) <- unique_sources

  if ("Composite" %in% names(cols)) {
    cols["Composite"] <- "#228B22"
  }

  # Plot logic
  p <- ggplot2::ggplot(plot_data, ggplot2::aes(x = .data$Source, y = .data$Value, fill = .data$Source)) +
    ggplot2::geom_col(show.legend = FALSE, alpha = 0.85) +
    ggplot2::facet_wrap(~ .data$Metric, scales = "free_y") +
    ggplot2::scale_fill_manual(values = cols) +
    ggplot2::theme_minimal() +
    ggplot2::labs(
      title = "ISDM Model Evaluation: Dataset Comparison",
      subtitle = paste("Seed:", attr(x, "settings")$seed),
      x = NULL, y = "Metric Value"
    ) +
    ggplot2::theme(axis.text.x = ggplot2::element_text(angle = 45, hjust = 1))

  print(p)
  invisible(p)
}


#' @rdname ISDMmetrics-methods
#' @export
`[.ISDMmetrics` <- function(x, ...) {
  settings_attr <- attr(x, "settings")
  bg_attr <- attr(x, "bg_points")

  out <- NextMethod("[")

  class(out) <- c("ISDMmetrics", "list")
  attr(out, "settings") <- settings_attr
  attr(out, "bg_points") <- bg_attr

  return(out)
}

#' @rdname ISDMmetrics-methods
#' @description \code{get_background} is a helper function to extract the
#' \code{BackgroundPoints} object from an \code{ISDMmetrics} object.
#'
#' @param x An object of class \code{ISDMmetrics}.
#' @return The \code{BackgroundPoints} object if present, otherwise \code{NULL}.
#' @export
get_background <- function(x) {
  if (!inherits(x, "ISDMmetrics")) {
    stop("Argument 'x' must be an object of class 'ISDMmetrics'.")
  }

  bg <- attr(x, "bg_points")

  if (is.null(bg)) {
    message("No background points found. This usually occurs if no Presence-Only (PO) data was evaluated.")
    return(NULL)
  }

  return(bg)
}


#--- Functions to compute evaluation metrics for continuous-outcome responses ----

# RMSE (root mean square error),
rmse <- function(observed, predicted) {
  stopifnot(length(observed) == length(predicted))
  sqrt(mean((observed - predicted)^2, na.rm = TRUE))
}

# MAE (mean absolute error)
mae <- function(observed, predicted) {
  stopifnot(length(observed) == length(predicted))
  mean(abs(observed - predicted), na.rm = TRUE)
}

# MAPE (mean absolute percentage error) -- only valid for non-null response
mape <- function(observed, predicted) {
  stopifnot(length(observed) == length(predicted))
  100 * mean(abs(observed - predicted) / observed, na.rm = TRUE)
}

# Pseudo R-squared
r_squared <- function(observed, predicted) {
  stopifnot(length(observed) == length(predicted))
  ss_res <- sum((observed - predicted)^2, na.rm = TRUE)
  ss_tot <- sum((observed - mean(observed, na.rm = TRUE))^2, na.rm = TRUE)
  1 - ss_res / ss_tot
}
