## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  eval = TRUE
)
options(rmarkdown.html_vignette.check_title = FALSE)

## ----warning=FALSE,message=FALSE----------------------------------------------
library(isdmtools)
library(sf)
library(terra)
library(dplyr)
library(ggplot2)

## -----------------------------------------------------------------------------
# Simulate a list of presence-only and count data
set.seed(42)
presence_data <- data.frame(
  x = runif(100, 0, 4),
  y = runif(100, 6, 13),
  site = rbinom(100, 1, 0.6)
) |> st_as_sf(coords = c("x", "y"), crs = 4326)

count_data <- data.frame(
  x = runif(50, 0, 4),
  y = runif(50, 6, 13),
  count = rpois(50, 5)
) |> st_as_sf(coords = c("x", "y"), crs = 4326)

datasets_list <- list(Presence = presence_data, Count = count_data)

# Define the study region (e.g. Benin's boundary rectangle)
ben_coords <- matrix(c(0, 6, 4, 6, 4, 13, 0, 13, 0, 6), ncol = 2, byrow = TRUE)
ben_sf <- st_sf(
  data.frame(name = "Region"),
  st_sfc(st_polygon(list(ben_coords)),
    crs = 4326
  )
)

# Generate some continuous covariates
set.seed(42)
r <- rast(ben_sf, nrow = 100, ncol = 100)
r[] <- rnorm(ncell(r))
rtmp <- r
rtmp[] <- runif(ncell(r), 5, 10)

r <- c(r, rtmp + r)
names(r) <- c("cov1", "cov2")

## -----------------------------------------------------------------------------
# Create the DataFolds object using the default method
folds <- create_folds(datasets_list, ben_sf, cv_method = "cluster")

## ----fold-plot, fig.width = 6, fig.height = 6, out.height= "100%", fig.align = "center"----
# Visualize the folds with custom styling
plot(folds, nrow = 2, annotate = FALSE) +
  scale_x_continuous(breaks = seq(0, 4, 1)) +
  scale_y_continuous(breaks = seq(6, 13, 2)) +
  theme_minimal() +
  labs(title = "Spatial Block Partitioning")

## ----auto-plot, fig.width = 4, fig.height = 4, out.width = "100%", fig.align = "center"----
# Create the DataFolds object using the `spatialsample` blocking engine
fold_ss <- create_folds(datasets_list, ben_sf, cv_method = "block")

# Using the native autoplot of `spatialesample` which shows only pooled data
ggplot2::autoplot(fold_ss)

## -----------------------------------------------------------------------------
# Folds summary
summary(fold_ss)

## ----geo-diag, fig.width = 5, fig.height = 5, out.width = "90%"---------------
# Check spatial independence of folds using the default rho (N/A)
geo_diag <- check_folds(folds, plot = TRUE)
print(geo_diag)

# Plot results
plot(geo_diag)

## ----warning=FALSE,message=FALSE----------------------------------------------
# Check environmental balance of folds
set.seed(42) # set this for background sample reproducibility
env_diag <- check_env_balance(folds,
  covariates = r,
  n_background = 5000
)
print(env_diag)

## ----env-diag, fig.width = 6, fig.height = 4, out.width = "100%"--------------
# Plot outputs
plot(env_diag)

## -----------------------------------------------------------------------------
# Combined diagnostics
summarise_fold_diagnostics(geo_diag, env_diag)

## ----warning=FALSE,message=FALSE----------------------------------------------
# Continuous (temperature) and categorical (land cover) variables
set.seed(42)

r_temp <- rast(ben_sf, nrow = 100, ncol = 100, val = runif(10000, 15, 25))
r_land <- rast(ben_sf, nrow = 100, ncol = 100, val = sample(1:4, 10000, TRUE))
levels(r_land) <- data.frame(ID = 1:4, cover = c("Forest", "Grass", "Urban", "Water"))
env_stack <- c(r_temp, r_land)
names(env_stack) <- c("temperature", "land_use")

# Run the test with 5000 background cells and use boxplot
env_mixed <- check_env_balance(
  folds,
  covariates = env_stack,
  n_background = 5000,
  plot_type = "boxplot"
)

print(env_mixed)

## ----env-cat, fig.width = 6, fig.height = 4, out.width = "100%"---------------
# Plot outputs
plot(env_mixed)

## -----------------------------------------------------------------------------
# Combined diagnostics
summarise_fold_diagnostics(geo_diag, env_mixed)

## -----------------------------------------------------------------------------
# Extract fold 1
splits_1 <- extract_fold(folds, fold = 1)

# Accessing the training and testing sets for the "Presence" source
head(splits_1$train$Presence)

head(splits_1$test$Presence)

